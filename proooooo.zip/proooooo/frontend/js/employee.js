function fetchUsers() {
    // ดึงข้อมูลผู้ใช้
    fetch('http://127.0.0.1:5001/api/users')
      .then(response => {
        if (!response.ok) throw new Error('Failed to fetch users');
        return response.json();
      })
      .then(users => {
        const employeeTableBody = document.querySelector("#employee-table");
        employeeTableBody.innerHTML = ""; // ล้างข้อมูลเดิมในตาราง
  
        // แสดงข้อมูลผู้ใช้ (user_id และ name)
        users.forEach(user => {
          const row = document.createElement("tr");
          row.innerHTML = `
            <td>${user.user_id}</td>
            <td>${user.name}</td>
          `;
          
          // เพิ่มแถวในตาราง
          employeeTableBody.appendChild(row);
        });
      })
      .catch(error => console.error('Error fetching users:', error));
  }
  
  // เรียกใช้งานฟังก์ชันเมื่อโหลดหน้า
  document.addEventListener('DOMContentLoaded', () => {
    fetchUsers();
  });
  