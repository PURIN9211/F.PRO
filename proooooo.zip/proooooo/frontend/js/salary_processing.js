function fetchUsersAndAttendance() {
    const selectedMonth = parseInt(document.getElementById('monthSelector').value);
    const selectedYear = parseInt(document.getElementById('yearSelector').value);
  
    const hourlyRate = 10; // ค่าแรงต่อชั่วโมง
    const weekdayOTMultiplier = 1.5; // อัตราค่า OT วันธรรมดา
    const weekendOTMultiplier = 2; // อัตราค่า OT วันเสาร์อาทิตย์
  
    // ดึงข้อมูลผู้ใช้
    fetch('http://127.0.0.1:5001/api/users')
      .then(response => {
        if (!response.ok) throw new Error('Failed to fetch users');
        return response.json();
      })
      .then(users => {
        // ดึงข้อมูล Attendance หลังจากดึง Users
        fetch('http://127.0.0.1:5001/api/attendance')
          .then(response => {
            if (!response.ok) throw new Error('Failed to fetch attendance logs');
            return response.json();
          })
          .then(attendanceLogs => {
            const employeeTableBody = document.querySelector("#employee-table");
            employeeTableBody.innerHTML = ""; // ล้างข้อมูลเดิมในตาราง
  
            // กรองเฉพาะ Attendance ที่อยู่ในเดือนที่เลือก
            const filteredLogs = attendanceLogs.filter(log => {
              const logDate = new Date(log.timestamp);
              return logDate.getMonth() === selectedMonth && logDate.getFullYear() === selectedYear;
            });
  
            // คำนวณเวลาทำงานในเดือนสำหรับผู้ใช้แต่ละคน
            users.forEach(user => {
              const userLogs = filteredLogs.filter(log => log.user_id === user.user_id);
              userLogs.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  
              let totalWorkMinutes = 0;
              let totalOTMinutes = 0;
  
              for (let i = 0; i < userLogs.length; i++) {
                const log = userLogs[i];
  
                // คำนวณเวลาทำงาน (Check-In/Check-Out)
                if (log.status === 0 && i + 1 < userLogs.length && userLogs[i + 1].status === 1) {
                  const checkInTime = new Date(userLogs[i].timestamp);
                  const checkOutTime = new Date(userLogs[i + 1].timestamp);
  
                  const workDuration = (checkOutTime - checkInTime) / (1000 * 60); // คำนวณเป็นนาที
                  totalWorkMinutes += workDuration;
  
                  i++; // ข้ามไป Check-Out
                }
  
                // คำนวณ OT (OT-In/OT-Out)
                if (log.status === 4 && i + 1 < userLogs.length && userLogs[i + 1].status === 5) {
                  const otInTime = new Date(userLogs[i].timestamp);
                  const otOutTime = new Date(userLogs[i + 1].timestamp);
  
                  const otDuration = (otOutTime - otInTime) / (1000 * 60); // คำนวณเป็นนาที
  
                  // ตรวจสอบว่าเป็นวันเสาร์หรืออาทิตย์ (ค่า getDay() = 0 คือวันอาทิตย์, 6 คือวันเสาร์)
                  const dayOfWeek = otInTime.getDay();
                  const otMultiplier = (dayOfWeek === 0 || dayOfWeek === 6) ? weekendOTMultiplier : weekdayOTMultiplier;
  
                  totalOTMinutes += otDuration * otMultiplier; // คำนวณ OT พร้อมอัตราคูณ
  
                  i++; // ข้ามไป OT-Out
                }
              }
  
              // คำนวณค่าจ้าง OT
              const totalOTHours = (totalOTMinutes / 60).toFixed(2);
              const otSalary = (totalOTHours * hourlyRate).toFixed(2);
  
              // แปลงเวลาทำงานปกติเป็นชั่วโมง
              const totalWorkHours = (totalWorkMinutes / 60).toFixed(2);
  
              // สร้างแถวใหม่ในตาราง
              const row = document.createElement("tr");
              row.innerHTML = `
                <td>${user.user_id}</td>
                <td>${user.name}</td>
                <td>${totalWorkHours} hours</td>
                <td>${totalOTHours} hours</td>
                <td>$${otSalary}</td>
                <td><input type="number" class="salary-input" placeholder="Enter salary" /></td>
                <td class="total-salary">$0.00</td>
              `;
              
              // เพิ่ม event listener สำหรับการกรอกเงินเดือน
              const salaryInput = row.querySelector(".salary-input");
              salaryInput.addEventListener("input", (e) => {
                const salary = parseFloat(e.target.value) || 0;
                const totalSalary = (salary + parseFloat(otSalary)).toFixed(2);
                row.querySelector(".total-salary").textContent = `$${totalSalary}`;
              });
  
              employeeTableBody.appendChild(row);
            });
          })
          .catch(error => console.error('Error fetching attendance logs:', error));
      })
      .catch(error => console.error('Error fetching users:', error));
  }
  
  // เรียกใช้งานฟังก์ชันเมื่อโหลดหน้า
  document.addEventListener('DOMContentLoaded', () => {
    fetchUsersAndAttendance();
  });
  