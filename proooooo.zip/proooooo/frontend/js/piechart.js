function fetchData(url) {
    return fetch(url)
      .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        alert('There was an issue fetching data, please try again later.');
      });
  }
  
  function mapStatus(statusCode) {
    const statusMap = {
      0: "Check-In",
      1: "Check-Out",
      2: "Break Out",
      3: "Break In",
      4: "OT In",
      5: "OT Out"
    };
    return statusMap[statusCode] || "Unknown";
  }
  
  function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toISOString().split('T')[0];
  }
  
  function getTimeFromTimestamp(dateStr) {
    const date = new Date(dateStr);
    return date.getHours() * 60 + date.getMinutes();
  }
  
  // Fetch Users
fetchData('http://127.0.0.1:5001/api/users')
.then(userData => {
  if (!userData || userData.length === 0) {
    console.error('No users found');
    return;
  }

  const userMap = {};
  userData.forEach(user => {
    userMap[user.user_id] = user.name || "No Name";
  });

  const totalEmployees = userData.length;

  // Fetch Attendance
  fetchData('http://127.0.0.1:5001/api/attendance')
    .then(attendanceData => {
      if (!attendanceData || attendanceData.length === 0) {
        console.error('No attendance data found');
        return;
      }

      const today = new Date().toISOString().split('T')[0];
      const todaysLogs = attendanceData.filter(log => formatDate(log.timestamp) === today);

      const uniqueUsers = new Set(todaysLogs.map(log => log.user_id));
      const totalEmployeesToday = uniqueUsers.size;

      let lateCount = 0;
      

      // Update the attendance log table
      const tableBody = document.getElementById("attendance-log-table");
      tableBody.innerHTML = ""; // Clear existing rows

      todaysLogs.forEach(log => {
        const checkInTime = getTimeFromTimestamp(log.timestamp);
        const status = checkInTime <= 9 * 60 ? "On Time" : "Late";

        if (status === "Late") {
          lateCount++;
        }

        const userName = userMap[log.user_id] || "No Name";

        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${log.user_id}</td>
          <td>${userName}</td>
          <td>${log.timestamp}</td>
          <td>${mapStatus(log.status)}</td>
        `;
        tableBody.appendChild(row);
      });

      const absentCount = totalEmployees - totalEmployeesToday;
      const onTimeCount = totalEmployees - absentCount; // Update onTimeCount as Total Employees - Absent

      // Update summary boxes
      document.getElementById("total-employees").textContent = `${totalEmployees} Total Employees`;
      document.getElementById("on-time").textContent = `${onTimeCount} On Time`;
      document.getElementById("late").textContent = `${lateCount} Late`;
      document.getElementById("absent").textContent = `${absentCount} Absent`;
    
  
          // Create Pie Chart
          const ctx = document.getElementById('attendance-pie-chart').getContext('2d');
          new Chart(ctx, {
            type: 'pie',
            data: {
              labels: ['On Time', 'Late', 'Absent'],
              datasets: [{
                data: [onTimeCount, lateCount, absentCount],
                backgroundColor: ['#4CAF50', '#FF5722', '#FFC107'],
                borderColor: ['#4CAF50', '#FF5722', '#FFC107'],
                borderWidth: 1
              }]
            },
            options: {
              responsive: true,
              plugins: {
                legend: {
                  position: 'top',
                },
                tooltip: {
                  callbacks: {
                    label: function(tooltipItem) {
                      return tooltipItem.label + ': ' + tooltipItem.raw;
                    }
                  }
                }
              }
            }
          });
        })
        .catch(error => console.error('Error fetching attendance logs:', error));
    })
    .catch(error => console.error('Error fetching users:', error));
  