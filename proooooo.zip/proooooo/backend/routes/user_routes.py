from flask import Blueprint, jsonify
from extensions import mongo

user_bp = Blueprint('user', __name__, url_prefix='/api')  # Prefix '/api'

@user_bp.route('/users', methods=['GET'])  # Route คือ '/api/users'
def get_users():
    try:
        users_collection = mongo.db.users
        users = users_collection.find()

        response_data = [
            {"_id": str(user["_id"]), "user_id": user.get("user_id"), "name": user.get("name")}
            for user in users
        ]
        return jsonify(response_data), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
