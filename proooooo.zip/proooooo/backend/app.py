from flask import Flask
from extensions import mongo, cors  # Import cors จาก extensions.py
from routes.holiday_routes import holiday_bp
from routes.user_routes import user_bp
from routes.attendance_routes import attendance_bp

app = Flask(__name__)

# ตั้งค่า MongoDB
app.config["MONGO_URI"] = "mongodb://localhost:27017/time_attendance_db"
mongo.init_app(app)
cors.init_app(app)  # กำหนด CORS ให้กับ Flask App

# ลงทะเบียน Blueprints
app.register_blueprint(holiday_bp)
app.register_blueprint(user_bp)
app.register_blueprint(attendance_bp)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
