from zk import ZK
from flask_pymongo import PyMongo

# ฟังก์ชันสำหรับเชื่อมต่อ ZKTeco
def connect_zk():
    zk = ZK('192.168.1.220', port=4370, timeout=5)
    try:
        conn = zk.connect()
        conn.disable_device()
        return conn
    except Exception as e:
        print(f"Error connecting to ZK device: {e}")
        return None

# ฟังก์ชันดึงข้อมูลผู้ใช้งาน
def fetch_users(mongo):
    conn = connect_zk()
    if not conn:
        return {"error": "Unable to connect to ZK device"}, 500

    try:
        users = conn.get_users()
        user_data = [{'user_id': user.user_id, 'name': user.name} for user in users]

        users_collection = mongo.db.users
        users_collection.delete_many({})
        users_collection.insert_many(user_data)

        conn.enable_device()
        return user_data, 200
    except Exception as e:
        return {"error": str(e)}, 500
    finally:
        conn.disconnect()
